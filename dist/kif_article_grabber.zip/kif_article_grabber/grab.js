chrome.runtime.onMessage.addListener(function (msg, _, sendResponse) {
	sendResponse(document.getElementsByClassName("article-body")[0].innerHTML.toString().replace(/\<div(.|\n)*\/div\>\n/,''));
});