chrome.browserAction.onClicked.addListener(function(tab) {
	if (tab.url.indexOf('https://support.plesk.com/hc') != -1) {
		chrome.tabs.executeScript(null, {file: "grab.js"}, function () {
			chrome.tabs.sendMessage(tab.id, "Grabbing article", function (response) {
				var r_html = response;
				copyToClipboard(r_html);
				chrome.notifications.create(
					'Notify success',{
						type: 'basic',
    					title: "HTML in is clipboard",
    					message: "Ready to import data!",
    					iconUrl: "icon.png"
    				},
					function() {} 
				);
			});
		});
	} else {
		chrome.notifications.create(
			'Notify fail',{
				type: 'basic',
    			title: "Wrong URL",
    			message: "This extension works only on https://support.plesk.com/hc",
    			iconUrl: "icon.png"
    		},
			function() {} 
		);
	}
});

function copyToClipboard(i_html) {
    const input = document.createElement("input");
    input.style.position = "fixed";
    input.style.opacity = 0;
    input.value = i_html;
    document.body.appendChild(input);
    input.select();
    document.execCommand("Copy");
    document.body.removeChild(input);
};